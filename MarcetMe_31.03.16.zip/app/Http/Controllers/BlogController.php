<?php namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\Category;
use App\Models\Blog;
use App\Models\Cms;
use App\Models\Article;
use Illuminate\Support\Facades\Validator;
use Auth;
use App\Models\UserComment;


class BlogController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		//$this->middleware('auth');
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
		$data = array();

$allcategory = Category::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 
		
		$latestArticles = Article::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 
			   
		$latestBlogs = Blog::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 

		$homecontent = Cms::where('is_active', 1)
               ->where('id', 5) ->get(); 

	
		
		$data['allcategory'] = $allcategory;
		$data['latestArticles'] = $latestArticles;
		$data['latestBlogs'] = $latestBlogs;
		$data['homecontent'] = $homecontent[0]->description;

		$latestBlogs = Blog::where('is_active', 1)
               ->orderBy('id', 'desc') ->get();      
		
		$homecontent = Cms::where('is_active', 1)
               ->where('id', 5) ->get();
		
		$latest_blog_list = Blog::where('is_active', 1)
               ->limit(3) ->get(); 

			   
	
		$data['blogs'] = $latestBlogs;
		$data['homecontent'] = $homecontent[0]->description;
		$data['latest_blog_list'] = $latest_blog_list;

		return view('blog_list',$data);
	}
	
	public function details($id){




	
		$blog = Blog::where('is_active', 1)
               ->where('id', $id) ->get(); 
		$data['blog'] = $blog[0];
		/*$latest_blog_list = Blog::where('is_active', 1)
               ->limit(3) ->get(); 
		
		//echo "<pre>";
		//print_r($article_list);die;

		
		$homecontent = Cms::where('is_active', 1)
               ->where('id', 5) ->get(); 
		//echo "<pre>";
		//print_r($homecontent);die;
		
		
		$data['homecontent'] = $homecontent[0]->description;
		$data['latest_blog_list'] = $latest_blog_list;*/
		// this section for show comment

		$commentView=UserComment::
		leftJoin('users','users.id','=','user_comments.user_id')
		->where('user_comments.is_active',1)->orderBy('user_comments.id','desc')->get()->toarray();
		$data['userComments']=$commentView;

        
		//$data['profilePicture'] = Auth::user()->profile_picture();
		//print_r($commentView);die();

		return view('blog_details',$data);
	}


	public function getCms(Request $request,$id)
	{
       // logic done for cms view 
         $cms=Cms::findOrFail($id);
         $data['cmsTitle']= $cms['title']; 
         $data['cmsDescription']= $cms['description']; 
     //dd($data);
		return view('cmsView',$data);
	}


	public function contactUs(Request $request)
	{
		$data=array();
        if ($request->isMethod('post')) {
       $validator = Validator::make($request->all(), [
		'name' => 'required',
		'email' => 'required',
		 'address' => 'address'
		]);
		
		if ($validator->fails()) {
		
			//echo "<pre>";
			//print_r($validator);die;
			return redirect('contact-us')
                        ->withErrors($validator)
                        ->withInput();
		}
		else{

			// mail send code done this area
/* $data['name']=$request['name'];
        $subject="Registrstion Email";
      // this section code implement for email sending to user
		Mail::send('emails.registerEmail', $data, function($message) use ($subject)
       {

       $message->from('admin@marcetme.com', 'Admin');
	
       $message->to('kaushikdutta@matrixnmedia.com')->subject($subject); 

     }
     );
		print_r('success');*/

			
		}
	}



		return view('contactUs',$data);
	}

	public function addBlog(Request $request)
	{
		$data=array();
         if ($request->isMethod('post')) {
		$validator = Validator::make($request->all(), [
            'title' => 'required|unique:blogs|max:255',
            'description' => 'required',
            'image' => 'required',
        ]);

        if ($validator->fails()) {
		
			//echo "<pre>";
			//print_r($validator);die;
			return redirect('add-blog')
                        ->withErrors($validator)
                        ->withInput();
		}
		else{
		
		$blog = new Blog;

		$blog->title = $request->title;
		$blog->description = $request->description;
		$blog->user_id = Auth::user()->id;
		
		if ($request->hasFile('image'))
			{  
				$image = $request->file('image');
				$filename  = time() . '.' . $image->getClientOriginalExtension();
				$destinationPath = public_path('blog_images/');  
				$path = public_path('blog_images/thumbnails/');         
                //Image::make($image->getRealPath())->resize(200, 200)->save($path);				
				$image->move($destinationPath, $filename);

                $blog->image = $filename;                
           }
		   
			$blog->save();

			return redirect('manage-blogs');
		}
	}
		
		
		return view('addBlog',$data);
	}

	public function manageBlog()
	{
		$data=array();
		$count_blog = DB::table('blogs')
                     ->select(DB::raw('count(*) as blog_count'))
                     ->get();
		$count_blog_no = $count_blog[0]->blog_count;
	
		$blog = Blog::where('is_active', 1)
					 ->where('is_active', 1)
                     ->where('user_id',Auth::user()->id)
                     ->where('verify',1)
               ->orderBy('id', 'desc')
              ->paginate(10);
               
		
		$data['blog']= $blog;
		$data['count_blog']= $count_blog_no;
		return view('manageBlog',$data);
	}


	public function editBlog($id, Request $request){	


	    $data = array();
		if ($request->isMethod('post')) {
		
		$validator = Validator::make($request->all(), [
            'title' => 'required|max:255',
            'description' => 'required',
           // 'image' => 'required',
        ]);

        if ($validator->fails()) {
		
			//echo "<pre>";
			//print_r($validator);die;
			return redirect('edit-blog'.$id)
                        ->withErrors($validator)
                        ->withInput();
		}
		else{
			$blog = new Blog;
			$blog->title = $request->title;
			$blog->description = $request->description;
			//$cms->save();
			
			/******* update code *******/
			$update_arr = array(
											'title'=>$request->title,
											'description' => $request->description											
									);
			if ($request->hasFile('image'))
			{  
				$image = $request->file('image');
				$filename  = time() . '.' . $image->getClientOriginalExtension();
				$destinationPath = public_path('blog_images/');     
				$path = public_path('blog_images/thumbnails/');      				
                //Image::make($image->getRealPath())->resize(200, 200)->save($path);				
				$image->move($destinationPath, $filename);

                $update_arr['image'] = $filename;                
           }
									
			$blog::where('id',$id)
			->update($update_arr);
			/***** End of update code *******/
			return redirect('manage-blogs');
		}
	}
		$blog = Blog::find($id);
		

		$data['blog'] = $blog;
		return view('editBlog',$data);
	}

}
