<?php namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use DB;
use App\Models\Blog;
use Illuminate\Html\FormFacade;
use Illuminate\Html\HtmlFacade;
use Illuminate\Support\Facades\Validator;

class BlogController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('adminauth');
		
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
	
		$count_blog = DB::table('blogs')
                     ->select(DB::raw('count(*) as blog_count'))
                     ->where('is_active', 1)
                     ->get();
		$count_blog_no = $count_blog[0]->blog_count;
	
		$blog = Blog::where('is_active', 1)
               ->orderBy('id', 'desc')
              ->paginate(10);
               
		
		$data['blog']= $blog;
		$data['count_blog']= $count_blog_no;
		return view('admin/blog/list',$data);
	}

	public function add(Request $request){
	
		if ($request->isMethod('post')) {
		
		$validator = Validator::make($request->all(), [
            'title' => 'required|unique:blogs|max:255',
            'description' => 'required',
            'image' => 'required',
        ]);

        if ($validator->fails()) {
		
			//echo "<pre>";
			//print_r($validator);die;
			return redirect('admin/blog/add')
                        ->withErrors($validator)
                        ->withInput();
		}
		else{
		
		$blog = new Blog;

		$blog->title = $request->title;
		$blog->description = $request->description;
		
		if ($request->hasFile('image'))
			{  
				$image = $request->file('image');
				$filename  = time() . '.' . $image->getClientOriginalExtension();
				$destinationPath = public_path('blog_images/');  
				$path = public_path('blog_images/thumbnails/');         
                //Image::make($image->getRealPath())->resize(200, 200)->save($path);				
				$image->move($destinationPath, $filename);

                $blog->image = $filename;                
           }
		   
			$blog->save();

			return redirect('admin/blogs');
		}
	}
		
		$data = array();
		return view('admin/blog/blog_add',$data);
	}
	
	public function edit($id, Request $request){		
		
		if ($request->isMethod('post')) {
		
		$validator = Validator::make($request->all(), [
            'title' => 'required|max:255',
            'description' => 'required',
           // 'image' => 'required',
        ]);

        if ($validator->fails()) {
		
			//echo "<pre>";
			//print_r($validator);die;
			return redirect('admin/blog/edit/'.$id)
                        ->withErrors($validator)
                        ->withInput();
		}
		else{
			$blog = new Blog;
			$blog->title = $request->title;
			$blog->description = $request->description;
			//$cms->save();
			
			/******* update code *******/
			$update_arr = array(
											'title'=>$request->title,
											'description' => $request->description											
									);
			if ($request->hasFile('image'))
			{  
				$image = $request->file('image');
				$filename  = time() . '.' . $image->getClientOriginalExtension();
				$destinationPath = public_path('blog_images/');     
				$path = public_path('blog_images/thumbnails/');      				
                //Image::make($image->getRealPath())->resize(200, 200)->save($path);				
				$image->move($destinationPath, $filename);

                $update_arr['image'] = $filename;                
           }
									
			$blog::where('id',$id)
			->update($update_arr);
			/***** End of update code *******/
			return redirect('admin/blogs/');
		}
	}
		$blog = Blog::find($id);
		
		$data=array();
		$data['blog'] = $blog;
		return view('admin/blog/blog_edit',$data);
	}
  public function remove(Request $request)
   {
   	DB::table('blogs')
            ->where('id', $request['id'])
            ->update(['is_active' => 0]);
      return $request['id'];
   }
	
}