<?php 
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\Category;
use App\Models\Article;
use App\Models\Cms;
use App\Models\Blog;

class CmsController extends Controller {}