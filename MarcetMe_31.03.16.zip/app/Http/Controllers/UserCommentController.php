<?php 
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Models\Category;
use App\Models\Blog;
use App\Models\Cms;
use App\Models\Article;
use Illuminate\Support\Facades\Validator;
use Auth;
use App\Models\UserComment;


class UserCommentController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		//$this->middleware('auth');
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
		$data = array();

$allcategory = Category::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 
		
		$latestArticles = Article::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 
			   
		$latestBlogs = Blog::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 

		$homecontent = Cms::where('is_active', 1)
               ->where('id', 5) ->get(); 

	
		
		$data['allcategory'] = $allcategory;
		$data['latestArticles'] = $latestArticles;
		$data['latestBlogs'] = $latestBlogs;
		$data['homecontent'] = $homecontent[0]->description;

		$latestBlogs = Blog::where('is_active', 1)
               ->orderBy('id', 'desc') ->get();      
		
		$homecontent = Cms::where('is_active', 1)
               ->where('id', 5) ->get();
		
		$latest_blog_list = Blog::where('is_active', 1)
               ->limit(3) ->get(); 

			   
	
		$data['blogs'] = $latestBlogs;
		$data['homecontent'] = $homecontent[0]->description;
		$data['latest_blog_list'] = $latest_blog_list;

		return view('blog_list',$data);
	}
   
    public function create(Request $request)
    {
      if(Auth::check())
      {
      	$userComment = new UserComment;
      $userComment->user_id=Auth::user()->id;
      $userComment->blog_id=$request->get('blog_id');
      $userComment->comment=$request->get('comment');
      $blogId=$request->get('blog_id');
      $name=Auth::user()->name;
      $comment=$request->get('comment');
      if(isset(Auth::user()->profile_picture))
      {
      	if(Auth::user()->profile_picture!="")
	      {
	      	$profileUrl=url('timthumb/timthumb.php').'?src=/user_images/'.Auth::user()->profile_picture.'&w=48&h=48&q=48';
	      }
	      else
	      	$profileUrl=url('images/no_user.png');
	  }
      else
          $profileUrl=url('images/no_user.png');
      
      $commentHtml='<li><div class="smallimg"><img alt="" src='.$profileUrl.'></div><div class=\"txts-area\"><div class="comm_name">'.$name.'</div>div class="comment">'.$comment.'</div><div class="like-area"><a data-comment_id="18" class="reply_comment" href="javascript:void(0)"><i class="fa fa-comment"></i> Reply</a></div></div></li>';
      	  $userComment->save();
         return $commentHtml;
      }	
    }


}
