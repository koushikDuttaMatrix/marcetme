<?php 
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\Category;
use App\Models\Article;
use App\Models\Cms;
use App\Models\Blog;

class ArticleController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		//$this->middleware('auth');
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
	
              $data = array();

$allcategory = Category::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 
		
		$latestArticles = Article::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 
			   
		$latestBlogs = Blog::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 

		$homecontent = Cms::where('is_active', 1)
               ->where('id', 5) ->get(); 

	
		
		$data['allcategory'] = $allcategory;
		$data['latestArticles'] = $latestArticles;
		$data['latestBlogs'] = $latestBlogs;
		$data['homecontent'] = $homecontent[0]->description;


		$latestArticles = Article::where('is_active', 1)
               ->orderBy('id', 'desc') ->get();      
		
		$homecontent = Cms::where('is_active', 1)
               ->where('id', 5) ->get();
		
		$latest_article_list = Article::where('is_active', 1)
               ->limit(3) ->get(); 

			   
		
		$data['articles'] = $latestArticles;
		$data['homecontent'] = $homecontent[0]->description;
		$data['latest_article_list'] = $latest_article_list;

		return view('article_list',$data);
	}
	
	public function details($id){



 $data = array();

$allcategory = Category::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 
		
		$latestArticles = Article::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 
			   
		$latestBlogs = Blog::where('is_active', 1)
               ->orderBy('id', 'desc') ->get(); 

		$homecontent = Cms::where('is_active', 1)
               ->where('id', 5) ->get(); 

	
		
		$data['allcategory'] = $allcategory;
		$data['latestArticles'] = $latestArticles;
		$data['latestBlogs'] = $latestBlogs;
		$data['homecontent'] = $homecontent[0]->description;





	
		$article = Article::where('is_active', 1)
               ->where('id', $id) ->get(); 
		
		$latest_article_list = Article::where('is_active', 1)
               ->limit(3) ->get(); 
		
		//echo "<pre>";
		//print_r($article_list);die;

		
		$homecontent = Cms::where('is_active', 1)
               ->where('id', 5) ->get(); 
		//echo "<pre>";
		//print_r($homecontent);die;

		$data['article'] = $article[0];
		$data['homecontent'] = $homecontent[0]->description;
		$data['latest_article_list'] = $latest_article_list;

		return view('article_details',$data);
	}

}
